document.addEventListener("DOMContentLoaded", () => {
    const carousels = document.querySelectorAll(".carousel");

    carousels.forEach((carousel) => {
        const items = carousel.querySelector(".carousel-items");
        const prevBtn = carousel.querySelector(".prev");
        const nextBtn = carousel.querySelector(".next");

        let scrollPosition = 0;

        prevBtn.addEventListener("click", () => {
            console.log("Prev button clicked");
            scrollPosition = Math.max(scrollPosition - 200, 0);
            items.scrollTo({ left: scrollPosition, behavior: "smooth" });
        });

        nextBtn.addEventListener("click", () => {
            console.log("Next button clicked");
            scrollPosition = Math.min(scrollPosition + 200, items.scrollWidth);
            items.scrollTo({ left: scrollPosition, behavior: "smooth" });
        });

        items.addEventListener("click", (event) => {
            console.log("Image clicked:", event.target);
            if (event.target.tagName === "IMG") {
                const component = event.target.getAttribute("data-component");
                const src = event.target.getAttribute("src");
                document.getElementById(`watch-${component}`).setAttribute("src", src);
            }
        });
    });
});