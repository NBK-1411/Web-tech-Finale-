document.addEventListener('DOMContentLoaded', () => {
    // Element References
    const caseSelect = document.getElementById('case-select');
    const dialSelect = document.getElementById('dial-select');
    const handsSelect = document.getElementById('hands-select');
    const wristbandSelect = document.getElementById('wristband-select');

    const casePreview = document.getElementById('case-preview');
    const dialPreview = document.getElementById('dial-preview');
    const handsPreview = document.getElementById('hands-preview');
    const wristbandPreview = document.getElementById('wristband-preview');

    // Event Handlers
    function updatePreview(selectElement, previewElement) {
        const selectedOption = selectElement.options[selectElement.selectedIndex];
        const imageSrc = selectedOption.getAttribute('data-image');
        previewElement.src = imageSrc;
    }

    // Attach Event Listeners
    caseSelect.addEventListener('change', () => updatePreview(caseSelect, casePreview));
    dialSelect.addEventListener('change', () => updatePreview(dialSelect, dialPreview));
    handsSelect.addEventListener('change', () => updatePreview(handsSelect, handsPreview));
    wristbandSelect.addEventListener('change', () => updatePreview(wristbandSelect, wristbandPreview));
});