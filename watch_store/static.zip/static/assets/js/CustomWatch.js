const components = {
    cases: [
      { src: "/public/Images/Case3.jpg.png", price: 50, label: "Case 1" },
      { src: "/public/Images/Case373.jpg.png", price: 60, label: "Case 2" },
      { src: "/public/Images/Case5.jpg.png", price: 70, label: "Case 3" },
      { src: "/public/Images/Case6.jpg.png", price: 80, label: "Case 4" },
    ],
    dials: [
      { src: "/public/Images/Dial56.jpg.png", price: 30, label: "Dial 1" },
      { src: "/public/Images/Dial5858.jpg.png", price: 40, label: "Dial 2" },
      { src: "/public/Images/Dial69.jpg.png", price: 50, label: "Dial 3" },
      { src: "/public/Images/Dial754.jpg.png", price: 60, label: "Dial 4" },
    ],
    hands: [
      { src: "/public/Images/Hands10.jpg.png", price: 20, label: "Hands 1" },
      { src: "/public/Images/Hands11.jpg.png", price: 25, label: "Hands 2" },
      { src: "/public/Images/Hands6.jpg.png", price: 30, label: "Hands 3" },
      { src: "/public/Images/Hands8.jpg.png", price: 35, label: "Hands 4" },
    ],
    bezels: [
      { src: "/public/Images/Bezel3.jpg.png", price: 15, label: "Bezel 1" },
      { src: "/public/Images/Bezel858.jpg.png", price: 20, label: "Bezel 2" },
      { src: "/public/Images/Bezel7.jpg.png", price: 25, label: "Bezel 3" },
      { src: "/public/Images/Bezel6.jpg.png", price: 30, label: "Bezel 4" },
    ],
    wristbands: [
      { src: "/public/Images/Strap9.jpg.png", price: 40, label: "Wristband 1" },
      { src: "/public/Images/Strap2345.jpg.png", price: 45, label: "Wristband 2" },
      { src: "/public/Images/Strap1.jpg.png", price: 50, label: "Wristband 3" },
      { src: "/public/Images/Strap8.jpg.png", price: 55, label: "Wristband 4" },
    ],
  };
  
  // Store the selected components and total price
  let selectedComponents = {
    cases: null,
    dials: null,
    hands: null,
    bezels: null,
    wristbands: null,
  };
  let totalPrice = 0;
  
  // Function to dynamically load options for the selected category
  function loadOptions(category) {
    const container = document.getElementById("option-container");
    container.innerHTML = ""; // Clear previous options
  
    // Dynamically create option images
    components[category].forEach((option, index) => {
      const img = document.createElement("img");
      img.src = option.src;
      img.alt = option.label;
      img.className = "option-image"; // Add a class for styling
      img.onclick = () => selectOption(category, index, img); // Add click event
      container.appendChild(img);
    });
  }
  
  // Function to handle selection of an option
  function selectOption(category, index, imgElement) {
    const preview = document.getElementById(`${category}-preview`);
    const selectedOption = components[category][index];
  
    // Update the preview image for the selected category
    preview.src = selectedOption.src;
  
    // Highlight the selected image
    document.querySelectorAll(`#option-container img`).forEach((img) => {
      img.classList.remove("selected");
    });
    imgElement.classList.add("selected");
  
    // Update the total price
    if (selectedComponents[category]) {
      totalPrice -= selectedComponents[category].price; // Deduct the previous price
    }
    selectedComponents[category] = selectedOption;
    totalPrice += selectedOption.price;
    document.getElementById("total-price").textContent = totalPrice.toFixed(2); // Update displayed total price
  }
  
  // Function to switch between categories
  function changeCategory(category) {
    loadOptions(category); // Load options for the selected category
  }
  
  // Initialize the page by loading the first category
  document.addEventListener("DOMContentLoaded", () => {
    loadOptions("cases"); // Default to "cases"
  });