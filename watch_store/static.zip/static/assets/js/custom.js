document.addEventListener("DOMContentLoaded", () => {
    const components = {
        case: ["Case3.jpg.png", "Case2344.jpg.png", "Case6.jpg.png"],
        dial: ["Dial56.jpg.png", "Dial5858.jpg.png", "Dial69.jpg.png"],
        hands: ["Hands10.jpg.png", "Hands6.jpg.png", "Hands7.jpg.png"],
        strap: ["Strap9.jpg.png", "Strap2345.jpg.png", "Strap1.jpg.png"],
        bezel: ["Bezel3.jpg.png", "Bezel858.jpg.png", "Bezel77.jpg.png"],
        secondhand: ["Second hand20.jpg.png", "Second hand1.jpg.png", "Second hand16.jpg.png"]
    };

    const prices = {
        case: 50,
        dial: 30,
        hands: 20,
        strap: 25,
        bezel: 40,
        secondhand: 15
    };

    const previewElements = {
        case: document.getElementById("watch-case"),
        dial: document.getElementById("watch-dial"),
        hands: document.getElementById("watch-hands"),
        strap: document.getElementById("watch-strap"),
        bezel: document.getElementById("watch-bezel"),
        secondhand: document.getElementById("watch-secondhand")
    };

    let currentSectionIndex = 0;
    const sections = document.querySelectorAll(".component-section");
    const totalPriceElement = document.getElementById("total-price");
    const prevButton = document.getElementById("prev-button");
    const nextButton = document.getElementById("next-button");

    // Populate component options
    Object.keys(components).forEach(type => {
        const container = document.getElementById(`${type}-options`);
        components[type].forEach(image => {
            const item = document.createElement("div");
            item.className = "component-item";
            item.innerHTML = `<img src="images/${image}" alt="${type}">`;
            item.addEventListener("click", () => {
                updatePreview(type, image);
                updatePrice();
                highlightSelected(container, item);
            });
            container.appendChild(item);
        });
    });

    // Update preview
    function updatePreview(type, image) {
        previewElements[type].style.backgroundImage = `url('images/${image}')`;
    }

    // Update price
    function updatePrice() {
        let total = 0;
        Object.keys(previewElements).forEach(type => {
            const element = previewElements[type];
            if (element.style.backgroundImage) {
                total += prices[type];
            }
        });
        totalPriceElement.textContent = total.toFixed(2);
    }

    // Highlight selected item
    function highlightSelected(container, selectedItem) {
        const items = container.querySelectorAll(".component-item");
        items.forEach(item => item.classList.remove("selected"));
        selectedItem.classList.add("selected");
    }

    // Navigation
    function showSection(index) {
        sections.forEach((section, i) => {
            section.classList.toggle("active", i === index);
        });
        prevButton.disabled = index === 0;
        nextButton.disabled = index === sections.length - 1;
    }

    prevButton.addEventListener("click", () => {
        if (currentSectionIndex > 0) {
            currentSectionIndex--;
            showSection(currentSectionIndex);
        }
    });

    nextButton.addEventListener("click", () => {
        if (currentSectionIndex < sections.length - 1) {
            currentSectionIndex++;
            showSection(currentSectionIndex);
        }
    });

    showSection(currentSectionIndex);
});